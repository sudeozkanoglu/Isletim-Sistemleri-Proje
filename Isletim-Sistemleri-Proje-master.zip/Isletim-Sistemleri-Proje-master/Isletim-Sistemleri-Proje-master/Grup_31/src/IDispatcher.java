

public interface IDispatcher {
	void start();
}
