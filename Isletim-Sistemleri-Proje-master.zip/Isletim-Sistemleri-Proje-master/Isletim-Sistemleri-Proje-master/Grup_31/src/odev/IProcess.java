package odev;

public class IProcessor {
	// Gönderilen prosesi çalıştırır.
		void run(ISpecialProcess process, int currentTime);
}
