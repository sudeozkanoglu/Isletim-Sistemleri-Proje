package OperatingSystems;

public class Process {
	int at;
	int priority;
	int bt;
	int mb;
	int yazici;
	int tarayici;
	int modem;
	int cd;
}
