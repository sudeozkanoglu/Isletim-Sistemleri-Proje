package odev;

public interface IProcessReader {

	// Yeni gelecek olan process olup olmadigini dondurur.
	boolean isEmpty();
}
