package odev;

public interface IProcessor {
	// Gelen Process calistirilir.
	void run(ISpecialProcess process, int currentTime);
}
