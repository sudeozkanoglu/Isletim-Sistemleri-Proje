
public interface IProcessor {
	// Gönderilen prosesi çalıştırır.
	void run(ISpecialProcess process, int currentTime);
}
