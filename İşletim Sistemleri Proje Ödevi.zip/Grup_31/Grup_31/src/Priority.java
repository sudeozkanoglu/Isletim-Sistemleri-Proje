
public enum Priority {
	RealTime, // Gerçek zamanlı öncelik
	Highest, // Yüksek düzey öncelik
	Medium, // Orta düzey öncelik
	Lowest; // Düşük düzey öncelik
}
